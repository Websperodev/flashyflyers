<?php
// This file was auto-generated from sdk-root/src/data/codestar/2017-04-19/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListProjects', 'input' => [], 'errorExpectedFromService' => false, ], ],];
